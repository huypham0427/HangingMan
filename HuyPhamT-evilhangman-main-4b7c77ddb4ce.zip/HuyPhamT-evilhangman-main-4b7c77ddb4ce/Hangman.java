import java.io.File;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Set;
import java.util.Collections;
public class Hangman{
    public String filename;
    public ArrayList<String> arr;
    public String family; 
    public HashMap<String,ArrayList<String>> map = new HashMap<String,ArrayList<String>>();;
    public Hangman(String dic, int len){
        filename = dic;
        arr = new ArrayList<String>();
        readFile(dic,len);
        String currentFamily0 = "";
        for (int i = 0; i< len; i++){
            currentFamily0 = currentFamily0 +"-";

        }
        family = currentFamily0;
    }

    public void readFile(String dic, int len)
    {
        File f = new File(dic);

        try
        {
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);

            String line;
            line = br.readLine();
            while (line != null)
            {
                if (len == line.length()){
                    arr.add(line);
                }
                line = br.readLine();// discard and read the next new line 

            }
        }
        catch (java.io.FileNotFoundException fnfe)
        {
            System.out.println("File not found: " + filename);
            System.exit(1);  // Maybe this is not what you want to do
        }
        catch (java.io.IOException ioe)
        {
            System.out.println("Oops. Something bad.");
            System.exit(1);
        }
    }

    public void printArray()
    {
        System.out.println(arr);
    }

    String getCurrentFamily(){
        return family;
    }

    void makeGuess(char g){
        // Loop through dictionary
        String temp = "";

        for (int i = 0; i< arr.size();i++){ // use size() for ArrayList
            // Loop through the word - make the family - after loop for each word want to check 
            for (int j = 0; j < arr.get(i).length(); j++){
                if( g == (arr.get(i).charAt(j))){ 
                    //temp = temp + g;
                    if (family.charAt(j) == '-'){
                        temp += g;
                    }

                }
                else{
                    if (family.charAt(j) == arr.get(i).charAt(j)){
                        temp = temp + arr.get(i).charAt(j);
                    }
                    else{
                        temp += "-";
                    }
                }

            }
            //String theWord= arr.get(i);

            if (!map.containsKey(temp)){
                //System.out.println("Hi");
                ArrayList<String> empList = new ArrayList<String>();
                // empList.add(arr.get(i));
                // map.put(temp,empList);
                empList.add(arr.get(i));
                map.put(temp,empList);
                temp = "";
                //System.out.println("The family is"+ temp);
            }
            else if(map.containsKey(temp)){
                ArrayList<String> empList = map.get(temp);
                empList.add(arr.get(i));
                //map.clear();

                temp = "";
            }
            //return myList;
        }
        Set<String>keys = map.keySet();
        // int maxkey = (Collections.max(map.values()));
        int maxValue = 0;
        String temp2 = family;
        for (String key : keys){
            if (map.get(key).size() > maxValue){
                maxValue = map.get(key).size();
                temp2 = key;
            }

        }
        family = temp2; // setting the longest family into the key 
        arr = map.get(temp2); // get the longest family to the array
        map.clear(); // clearing the map, the array is holding the key

        

    }
    
    //GameOver
    public boolean isGameOver(){
        boolean lose = false;
        if (family.contains("-")){
            lose = true;
        }
        return lose;
    }
    public boolean checkTheFamily(){
        if (arr.size() == 0){
            return true;
        }
        else{
            return false;
        }
    }
}
