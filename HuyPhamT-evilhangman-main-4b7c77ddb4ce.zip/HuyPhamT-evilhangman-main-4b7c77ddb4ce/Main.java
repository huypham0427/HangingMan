import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.io.File;
import javafx.scene.text.Text;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.HBox;
import javafx.collections.*; 
import javafx.scene.control.SelectionMode;


/**
 * Write a description of JavaFX class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Main extends Application
{
    // We keep track of the count, and label displaying the count:
    private int count = 0;

    Scene gameScene, menuScene;
    Stage gameWindow;
    TextField lengthField, dictionaryField, guessesField;
    TextField guessField;
    Label turnsLeft, family, gameOverMessage, guessed,guessLetter;
    Hangman hangman;
    String guessed1;
    ChoiceBox<String> choicebox;

    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage)
    {
        // Save value of Stage
        gameWindow = stage;

        guessed1= "";

        // Create a Button or any control item
        Button startButton = new Button("Start");

        // Labels
        Label lengthLabel = new Label("Word length:");
        Label dictionaryLabel = new Label("Dictionary:");
        Label guessesLabel = new Label("Guesses:");

        // Text Fields
        lengthField = new TextField("5");
        dictionaryField = new TextField("dictionary1000.txt");
        guessesField = new TextField("20");

        // Create a new grid pane
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setMinSize(300, 300);
        pane.setVgap(10);
        pane.setHgap(10);

        // Add the button and label into the pane
        pane.add(lengthLabel, 0, 0);
        pane.add(lengthField, 1, 0);
        pane.add(dictionaryLabel, 0, 1);
        pane.add(dictionaryField, 1, 1);
        pane.add(guessesLabel, 0, 2);
        pane.add(guessesField, 1, 2);
        pane.add(startButton, 0, 3);

        //set an action on the button using method reference
        startButton.setOnAction(this::buttonClick);

        // JavaFX must have a Scene (window content) inside a Stage (window)
        menuScene = new Scene(pane, 500,400);
        stage.setTitle("Evil Hangman");
        stage.setScene(menuScene);

        // The game scene
        Pane gamePane = new Pane();
        gameScene = new Scene(gamePane, 600, 400);
        Label turnsLabel = new Label("Turns: ");
        Label guessLabel = new Label("Guess a char: ");
        Button goButton = new Button("Go");
        goButton.setDefaultButton(true);
        family = new Label("");
        guessField = new TextField();
        turnsLeft = new Label("");
        guessed = new Label("");

        gamePane.getChildren().add(turnsLabel);
        turnsLabel.relocate(20, 20);
        gamePane.getChildren().add(turnsLeft);
        turnsLeft.relocate(100, 20);
        gamePane.getChildren().add(family);
        family.relocate(100, 50);
        gamePane.getChildren().add(guessLabel);
        guessLabel.relocate(20, 150);
        gamePane.getChildren().add(guessField);
        guessField.relocate(20, 200);
        gamePane.getChildren().add(goButton);
        goButton.relocate(20, 250);
        goButton.setOnAction(this::handleGoButton);

        // Make up the gameOverMessage
        gameOverMessage = new Label("You Lost!");
        Font comicSans = new Font("Comic Sans MS", 18);
        gameOverMessage.setFont(comicSans);
        gamePane.getChildren().add(gameOverMessage);
        gameOverMessage.relocate(100, 100);
        gameOverMessage.setVisible(false);

        // Create guessed letters message
        guessLetter = new Label("Guessed letter:" + "");
        comicSans = new Font("Comic Sans MS", 12);
        guessLetter.setFont(comicSans);
        gamePane.getChildren().add(guessLetter);
        guessLetter.relocate(100,100);
        guessLetter.setVisible(false);

        // Create a ChoiceBox for Dictionary
        //ChoiceBox choicebox = new ChoiceBox<String>();
        //choicebox.getItems().addAll("dictionary.txt", "dictionary10.txt", "dictionary100.txt", "dictionary1000.txt","dictionary5000.txt");
        
        
        //============================/
        //ChoiceBox<String> dictionaryField = new ChoiceBox<>();
        //dictionaryField.getItems().add("dictionary.txt", "dictionary10.txt", "dictionary100.txt", "dictionary1000.txt","dictionary5000.txt");
        // dictionaryField.getItems().add("dictionary10.txt");
        // dictionaryField.getItems().add("dictionary100.txt");
        // dictionaryField.getItems().add("dictionary1000.txt");
        // dictionaryField.getItems().add("dictionary5000.txt");
        //dictionaryField.getItems(hangman);
        //===========================/
        // Set default value
         //choicebox.setValue("dictionary10.txt");
        
        // // // Change the label of dictionary into ChoiceBox
        //pane.add(choicebox, 1, 1);



        // Show the Stage (window)
        stage.show();
    }

    /**
     * This will be executed when the button is clicked
     * It increments the count by 1
     */
    private void buttonClick(ActionEvent event)
    {
        gameWindow.setScene(gameScene);
        String lengthStr = lengthField.getText();
        int length = 0;
        
        // Try - catch the character inputs 
        try
        {
            length = Integer.parseInt(lengthStr);
        } catch(NumberFormatException nfe)
        {
            Alert alert2 = new Alert(AlertType.WARNING, "Inappropriate input", ButtonType.OK);
            alert2.showAndWait();
            if (alert2.getResult() == ButtonType.OK){
                start(gameWindow);
            }  
        }
        hangman = new Hangman(dictionaryField.getText(), length);
        turnsLeft.setText(guessesField.getText());
        family.setText(hangman.getCurrentFamily());
        
        
        // Do not allow players put invalid guesses
        try{
            count = Integer.parseInt(turnsLeft.getText());
        }catch(NumberFormatException nfe)
        {
            Alert alert2 = new Alert(AlertType.WARNING, "Inappropriate input", ButtonType.OK);
            alert2.showAndWait();
            if (alert2.getResult() == ButtonType.OK){
                start(gameWindow);
            }  
        }

        // Do not allow players put invalid word length
        if (hangman.checkTheFamily()){
            Alert alert = new Alert(AlertType.WARNING, "Inappropriate word length", ButtonType.OK);
            alert.showAndWait();
            if (alert.getResult() == ButtonType.OK){
                start(gameWindow);
            }
        }
        // ChoiceBox Menu
        //hangman = new Hangman(choicebox.getSelectionModel().getSelectedItem(),length);
        
    }

    /**
     * Handler for goButton
     */
    private void handleGoButton(ActionEvent event)
    {
        String guess = guessField.getText();

        //Minus lives when people used numbers 
        //Don't allow player type 2 characters at the same time
        if (Character.isDigit(guess.charAt(0)) || guess.length() > 1){
            count = count - 3;
            turnsLeft.setText("" + count);
        }

        //else if(guess.length() == 1){
        String guess1 = guessField.getText();
        guessed1 += guess1 + " ," ;
        guessLetter.setText("Guessed letters\n " + guessed1);
        guessLetter.setVisible(true);
        //}

        hangman.makeGuess(guess.charAt(0));
        family.setText(hangman.getCurrentFamily());
        count--;
        turnsLeft.setText("" + count);

        // Show up PlayerWon
        if (!hangman.isGameOver()){
            Alert alert = new Alert(AlertType.NONE, "You won!\n Would you like to play again?", ButtonType.YES, ButtonType.NO);
            // Sound for Victory
            String musicFile2 = "victory.wav";
            Media sound = new Media(new File(musicFile2).toURI().toString());
            MediaPlayer mediaPlayer2 = new MediaPlayer(sound);
            mediaPlayer2.play();
            alert.showAndWait();
            if(alert.getResult() == ButtonType.YES){
                start(gameWindow); // reset the game to Scene
            }
            else if (alert.getResult() == ButtonType.NO){
                System.exit(0); // exit the application 
            }
        }


        // Show up the message GameOver
        if (count <= 0){

            Alert alert = new Alert(AlertType.NONE, "You lost, Game Over!\n Would you like to play again?", ButtonType.YES, ButtonType.NO);
            // Sound for Failure
            String musicFile = "lose.wav";
            Media sound = new Media(new File(musicFile).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.play();
            alert.showAndWait();
            if(alert.getResult() == ButtonType.YES){
                start(gameWindow); // reset the game to Scene
            }
            else if (alert.getResult() == ButtonType.NO){
                System.exit(0);
            }
        }

    }
}